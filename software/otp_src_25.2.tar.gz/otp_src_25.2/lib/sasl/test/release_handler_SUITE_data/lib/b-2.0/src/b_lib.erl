-module(b_lib).
-compile(export_all).
foo() -> ok.
