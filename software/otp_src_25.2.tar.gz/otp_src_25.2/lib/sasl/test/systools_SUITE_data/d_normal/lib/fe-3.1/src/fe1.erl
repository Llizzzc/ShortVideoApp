-module(fe1).
-vsn("1.0").

-export([a/0]).

a() ->
    ok.
